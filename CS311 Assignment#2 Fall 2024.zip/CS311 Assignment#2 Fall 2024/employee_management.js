let xmlDoc;

// Load the XML data
function loadXMLData() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "employees.xml", true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            const parser = new DOMParser();
            xmlDoc = parser.parseFromString(xhr.responseText, "application/xml");
        } else {
            alert("Failed to load XML data.");
        }
    };
    xhr.send();
}

// Function to display all employee details in a table
function displayEmployees() {
    const employeeTableDiv = document.getElementById("employeeTable");

    // Check if the table is currently visible
    if (employeeTableDiv.style.display === "none" || employeeTableDiv.style.display === "") {
        // Create the table dynamically if not already displayed
        let output = `
            <table border="2" width="100%" cellspacing="0" cellpadding="10">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Salary</th>
                    </tr>
                </thead>
                <tbody>
        `;

        const employees = xmlDoc.getElementsByTagName("Employee");
        for (let i = 0; i < employees.length; i++) {
            const id = employees[i].getElementsByTagName("ID")[0].textContent;
            const name = employees[i].getElementsByTagName("Name")[0].textContent;
            const department = employees[i].getElementsByTagName("Department")[0].textContent;
            const salary = employees[i].getElementsByTagName("Salary")[0].textContent;

            output += `
                <tr>
                    <td>${id}</td>
                    <td>${name}</td>
                    <td>${department}</td>
                    <td>${salary}</td>
                </tr>
            `;
        }

        output += `
                </tbody>
            </table>
        `;

        // Set the table HTML and make it visible
        employeeTableDiv.innerHTML = output;
        employeeTableDiv.style.display = "block";
    } else {
        // Hide the table if already displayed
        employeeTableDiv.style.display = "none";
    }
}


// Function to add a new employee
function addEmployee() {
    const id = document.getElementById("id").value;
    const name = document.getElementById("name").value;
    const department = document.getElementById("department").value;
    const salary = document.getElementById("salary").value;

    const newEmployee = xmlDoc.createElement("Employee");

    const idElement = xmlDoc.createElement("ID");
    idElement.textContent = id;
    newEmployee.appendChild(idElement);

    const nameElement = xmlDoc.createElement("Name");
    nameElement.textContent = name;
    newEmployee.appendChild(nameElement);

    const departmentElement = xmlDoc.createElement("Department");
    departmentElement.textContent = department;
    newEmployee.appendChild(departmentElement);

    const salaryElement = xmlDoc.createElement("Salary");
    salaryElement.textContent = salary;
    newEmployee.appendChild(salaryElement);

    xmlDoc.getElementsByTagName("Employees")[0].appendChild(newEmployee);

    alert("New Employee Added!");
    document.getElementById("employeeForm").reset();
    displayEmployees();
}

// Function to delete an employee by ID
function deleteEmployee() {
    const deleteIdField = document.getElementById("deleteId");
    const deleteId = deleteIdField.value; // Get the value from the input field
    const employees = xmlDoc.getElementsByTagName("Employee");

    for (let i = 0; i < employees.length; i++) {
        const id = employees[i].getElementsByTagName("ID")[0].textContent;

        if (id === deleteId) {
            employees[i].parentNode.removeChild(employees[i]);
            alert(`Employee with ID ${deleteId} has been deleted.`);

            deleteIdField.value = ""; // Clear the input field after deletion
            displayEmployees(); // Refresh the displayed table
            return;
        }
    }

    alert("Employee with this ID not found.");
    deleteIdField.value = ""; // Clear the input field if not found
}


// Load XML data when the page loads
document.addEventListener("DOMContentLoaded", loadXMLData);
